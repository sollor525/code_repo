#!/bin/bash
# 开发者工具箱启动脚本

APP_DIR="$(dirname "$0")"
BINARY="$APP_DIR/common_tools"
STATIC_DIR="$APP_DIR/static"

# 检查二进制文件
if [ ! -f "$BINARY" ]; then
    echo "❌ 二进制文件不存在: $BINARY"
    exit 1
fi

# 检查静态文件目录
if [ ! -d "$STATIC_DIR" ]; then
    echo "❌ 静态文件目录不存在: $STATIC_DIR"
    exit 1
fi

# 设置工作目录
cd "$APP_DIR"

# 启动服务
echo "🚀 启动开发者工具箱..."
echo "📡 访问地址: http://localhost:8080"
echo "🛑 按 Ctrl+C 停止服务"
echo ""

exec "$BINARY"
